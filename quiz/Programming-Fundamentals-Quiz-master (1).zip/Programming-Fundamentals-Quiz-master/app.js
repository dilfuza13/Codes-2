class Account {
  constructor(accname, accno, balance) {
    this.name = accname;
    this.accno = accno;
    this.balance = balance;
    this.transactions = [];
  }

  //Your code here
}

module.exports = { Account };
